<?php
namespace App\Interfaces;

interface CanAssist {
    public function assist(): string;
}
