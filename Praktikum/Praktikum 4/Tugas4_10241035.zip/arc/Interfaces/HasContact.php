<?php
namespace App\Interfaces;

interface HasContact {
    public function getEmail(): string;
}
