<?php
namespace App\Interfaces;

interface HasIdentity {
	public function getId(): string;
}
?>
