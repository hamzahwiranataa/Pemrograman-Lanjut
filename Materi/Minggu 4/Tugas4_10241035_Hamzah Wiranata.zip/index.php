<?php
abstract class Hewan {
    protected $nama;

    public function __construct($nama) {
        $this->nama = $nama;
    }

    abstract public function suara();
}

class Kucing extends Hewan implements Peliharaan {
    public function suara() {
        echo "Meong!<br>";
    }

    public function beriMakan($makanan) {
        if (empty($makanan)) {
            throw new Exception("Makanan tidak boleh kosong");
        }
        if ($makanan === "Batu") {
            throw new Exception("Makanan tidak valid");
        }
        echo "{$this->nama} makan {$makanan}<br>";
    }
}

class Anjing extends Hewan implements Peliharaan {
    public function suara() {
        echo "Guk guk!<br>";
    }

    public function beriMakan($makanan) {
        if (empty($makanan)) {
            throw new Exception("Makanan tidak boleh kosong");
        }
        if ($makanan === "Batu") {
            throw new Exception("Makanan tidak valid");
        }
        echo "{$this->nama} makan {$makanan}<br>";
    }
}

interface Peliharaan {
    public function beriMakan($makanan);
}

try {
    $kucing = new Kucing("Kitty");
    $anjing = new Anjing("Doggo");

    $kucing->suara();
    $kucing->beriMakan("Ikan");

    $anjing->suara();
    $anjing->beriMakan("Tulang");

} catch (Exception $error) {
    echo "Error: " . $error->getMessage();
}
?>
